﻿namespace BlazorWebAppMovies.Components.Chart
{
    public enum ChartType
    {
        Line,
        Bar,
        Pie
    }
}

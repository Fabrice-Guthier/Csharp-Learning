﻿namespace Animal.Service.Entities
{
    public class Cat
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Color { get; set; }
    }
}

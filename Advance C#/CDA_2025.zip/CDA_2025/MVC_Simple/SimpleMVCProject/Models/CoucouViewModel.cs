﻿namespace SimpleMVCProject.Models
{
    public class CoucouViewModel
    {
        public string Hello { get; set; }
    }
}

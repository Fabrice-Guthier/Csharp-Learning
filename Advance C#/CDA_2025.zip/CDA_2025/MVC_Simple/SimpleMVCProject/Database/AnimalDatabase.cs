﻿using Microsoft.EntityFrameworkCore;
using SimpleMVCProject.Models;

namespace SimpleMVCProject.Database
{
    public class AnimalDatabase : DbContext
    {
        public AnimalDatabase(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Animal> Animals { get; set; }
    }
}

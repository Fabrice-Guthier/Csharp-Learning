﻿using AnimalsSQLSimple.Database;
using AnimalsSQLSimple.Model;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsSQLSimple.Repositories
{
    public class DogRepository
    {
        private AnimalDatabase _database;

        public DogRepository()
        {
            _database = new AnimalDatabase();
        }

        public IEnumerable<Dog> GetAll()
        {
            string sql = "SELECT id, name FROM Dog";
            List<Dog> dogList = new List<Dog>();

            using (SqlCommand command = new SqlCommand(sql, _database.GetConnection()))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Dog actualDog = new Dog
                        {
                            Id = reader.GetInt32(0),
                            Name = reader.GetString(1)
                        };
                        dogList.Add(actualDog);
                    }
                }
            }

            return dogList;
        }

        public Dog GetDogById(int id)
        {
            string sql = "SELECT id, name FROM dog WHERE id = @id";

            using (SqlCommand command = new SqlCommand(sql, _database.GetConnection())) 
            { 
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        return new Dog
                        {
                            Id = reader.GetInt32(0),
                            Name = reader.GetString(1)
                        };
                    }
                }
            }

            return null;
        }

        public void Create(string name)
        {
            // Si on veut pas deux fois le même nom de chien, soit on fait un select avant
            // Soit on rend la colonne unique en BDD + try catch
            string sql = "INSERT INTO Dog (name) VALUES (@name)";

            using (SqlCommand command = new SqlCommand(sql, _database.GetConnection()))
            {
                command.Parameters.AddWithValue("name", name);
                command.ExecuteNonQuery();
                Console.WriteLine($"Le chien {name} a bien été inséré en bdd");
            }
        }

        public void DeleteByName(string name)
        {
            string sql = "DELETE FROM Dog WHERE name = @name";

            using (SqlCommand command = new SqlCommand(sql, _database.GetConnection()))
            {
                command.Parameters.AddWithValue("name", name);
                int numberOfRowsDeleted = command.ExecuteNonQuery();
                Console.WriteLine($"{numberOfRowsDeleted} chiens supprimés");
            }
        }

        public void DeleteById(int id)
        {
            string sql = "DELETE FROM Dog WHERE id = @id";{

            if (GetDogById(id) != null)
            {
                using (SqlCommand command = new SqlCommand(sql, _database.GetConnection()))
                {
                    command.Parameters.AddWithValue("id", id);
                    int numberOfRowsDeleted = command.ExecuteNonQuery();
                    Console.WriteLine($"{numberOfRowsDeleted} chiens supprimés");
                }
            }
            else
                Console.WriteLine("Aucun chien avec cet id n'existe");
        }
    }
}

﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsSQLSimple.Database
{
    public class AnimalDatabase
    {
        private SqlConnection _sqlConnection;
        private string _connectionStringWithoutDb;
        private string _connectionString;

        public AnimalDatabase()
        {
            _connectionStringWithoutDb = "Server=CEDRICPC\\SQLEXPRESS;Initial Catalog = master;Trusted_Connection=True;TrustServerCertificate=True;Encrypt=False";
            _connectionString = "Server=CEDRICPC\\SQLEXPRESS;Database=CDA_Animal_Command;Trusted_Connection=True;TrustServerCertificate=True;Encrypt=False";
        }

        public SqlConnection GetConnectionWithoutDatabase()
        {
            _sqlConnection = new SqlConnection(_connectionStringWithoutDb);
            _sqlConnection.Open();
            return _sqlConnection;
        }

        public SqlConnection GetConnection()
        {
            _sqlConnection = new SqlConnection(_connectionString);
            _sqlConnection.Open();
            return _sqlConnection;
        }

        public void InitDatabase()
        {
            CreateDatabase();
            CreateDogTable();
        }

        private void CreateDatabase()
        {
            Console.WriteLine("Starting create Database");
            string sql = @"IF EXISTS (SELECT * FROM sys.databases WHERE name = 'CDA_Animal_Command')
                            SELECT 'Database already exists'
                            ELSE
                            CREATE DATABASE CDA_Animal_Command ";

            using (SqlCommand command = new SqlCommand(sql, GetConnectionWithoutDatabase()))
            {
                command.ExecuteNonQuery();
                Console.WriteLine("Database successfully database");
            }
        }

        private void CreateDogTable()
        {
            Console.WriteLine("Starting create table dog");
            string sql = @"IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Dog')
                                SELECT 'Dog table already exists'
                            ELSE
                                CREATE TABLE Dog (id INT PRIMARY KEY IDENTITY(1,1), name VARCHAR(50));";

            using (SqlCommand command = new SqlCommand(sql, GetConnection()))
            {
                command.ExecuteNonQuery();
                Console.WriteLine("Table dog created");
            }
        }
    }
}

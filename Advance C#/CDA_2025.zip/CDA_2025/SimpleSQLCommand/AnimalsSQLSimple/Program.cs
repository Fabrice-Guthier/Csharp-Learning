﻿// See https://aka.ms/new-console-template for more information
using AnimalsSQLSimple.Database;
using AnimalsSQLSimple.Repositories;

Console.WriteLine("Hello, World!");

AnimalDatabase animalDatabase = new AnimalDatabase();
animalDatabase.InitDatabase();

DogRepository dogRepository = new DogRepository();
dogRepository.Create("Preyja");
var dogList = dogRepository.GetAll();
dogList.ToList().ForEach(dog => Console.WriteLine(dog.ToString()));
dogRepository.DeleteByName("Preyja");

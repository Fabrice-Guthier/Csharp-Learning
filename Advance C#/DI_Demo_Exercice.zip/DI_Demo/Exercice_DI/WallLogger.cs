﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_DI
{
    public class WallLogger : ILogger
    {
        public void LogMessage(string message)
        {
            Console.WriteLine($"J'écris sur le mur : {message}");
        }
    }
}

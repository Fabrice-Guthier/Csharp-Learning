﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_DI
{
    public class FileLogger : ILogger
    {
        public void LogMessage(string message)
        {
            Console.WriteLine($"Je log dans un fichier : {message}");
        }
    }
}

﻿// See https://aka.ms/new-console-template for more information
using Exercice_DI;

LoggerService loggerService = new LoggerService(new WallLogger());
﻿namespace Exercice_DI
{
    public interface ILogger
    {
        void LogMessage(string message);
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_DI
{
    public class ConsoleLogger : ILogger
    {
        public void LogMessage(string message)
        {
            //Console.WriteLine("Message de log depuis la console : {0}", message);
            Console.WriteLine($"Message de log depuis la console : {message}");
        }
    }
}

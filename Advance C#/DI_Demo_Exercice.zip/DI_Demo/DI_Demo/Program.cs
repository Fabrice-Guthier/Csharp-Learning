﻿// See https://aka.ms/new-console-template for more information
using DI_Demo;

var clientXML = new Client(new XMLFileReader());
clientXML.GetFileInfo("osef");

var clientJson = new Client(new JSONFileReader());
clientJson.GetFileInfo("osef aussi");
﻿namespace DI_Demo
{
    public interface IFileReader
    {
        string ReadFile(string path);
    }
}
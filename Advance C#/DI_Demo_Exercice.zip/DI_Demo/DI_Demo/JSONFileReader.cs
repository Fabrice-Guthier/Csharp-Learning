﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DI_Demo
{
    public class JSONFileReader : IFileReader
    {
        public string ReadFile(string path)
        {
            // Lecture de fichier json
            return "Json - COUCOU";
        }
    }
}

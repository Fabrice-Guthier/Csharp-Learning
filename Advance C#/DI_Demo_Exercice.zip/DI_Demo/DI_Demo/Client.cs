﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DI_Demo
{
    public class Client
    {
        private IFileReader _reader;

        public Client(IFileReader reader)
        {
            _reader = reader;
        }

        public void GetFileInfo(string path)
        {
            var result = _reader.ReadFile(path);

            Console.WriteLine($"Resultat : {result}");
        }
    }
}

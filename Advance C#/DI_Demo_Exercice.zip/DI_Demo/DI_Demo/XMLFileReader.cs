﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DI_Demo
{
    public class XMLFileReader : IFileReader
    {
        public string ReadFile(string path)
        {
            return ReadXmlFile(path);
        }

        public string ReadXmlFile(string path)
        {
            // On implémente la lecture du fichier
            Console.WriteLine("Simuler la lecture de fichier...");
            return "Coucou";
        }
    }
}
